import { useRef, useEffect } from 'react';

export default function ThreatAnalysis() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const hasAnimatedRef = useRef(false);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !hasAnimatedRef.current) {
            hasAnimatedRef.current = true;
            const words = entry.target.querySelectorAll('.word');
            let delay = 0;
            const step = 0.04;

            words.forEach((word) => {
              (word as HTMLElement).style.animationDelay = `${delay}s`;
              word.classList.add('visible');
              delay += step;
            });

            const bodyEl = entry.target.querySelector('.reveal-body');
            if (bodyEl) {
              bodyEl.classList.add('visible');
            }

            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.3 }
    );

    observer.observe(section);

    return () => {
      observer.disconnect();
    };
  }, []);

  const headlineWords = "Sentri intercepts the breach before it reaches the surface.".split(' ');

  return (
    <section
      ref={sectionRef}
      className="relative flex items-center justify-center"
      style={{
        minHeight: '100vh',
        backgroundColor: '#f1f1ef',
        padding: '160px 24px',
      }}
    >
      <style>{`
        @keyframes slideUpFade {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .word {
          opacity: 0;
          transform: translateY(10px);
          display: inline-block;
        }
        .word.visible {
          animation: slideUpFade 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        .reveal-body {
          opacity: 0;
          transform: translateY(10px);
        }
        .reveal-body.visible {
          animation: slideUpFade 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
          animation-delay: 0.5s;
        }
      `}</style>
      <div style={{ maxWidth: '800px', width: '100%' }}>
        <h2
          className="font-display font-medium"
          style={{
            fontSize: '40px',
            lineHeight: 1.1,
            color: '#151515',
            marginBottom: '32px',
          }}
        >
          {headlineWords.map((word, i) => (
            <span key={i}>
              <span className="word">{word}</span>
              {i < headlineWords.length - 1 ? ' ' : ''}
            </span>
          ))}
        </h2>
        <div className="reveal-body">
          <p
            className="font-body"
            style={{
              fontSize: '18px',
              lineHeight: 1.4,
              color: '#151515',
              opacity: 0.7,
            }}
          >
            Utilizing a mesh of autonomous heuristics and behavioral topology mapping,
            we identify hostile intent in milliseconds. Our AI-driven threat detection
            engine continuously learns from global attack patterns, adapting its defenses
            in real-time to protect your infrastructure before a breach can materialize.
            Every packet is analyzed. Every anomaly is flagged. Every threat is neutralized
            at the edge.
          </p>
        </div>
      </div>
    </section>
  );
}
