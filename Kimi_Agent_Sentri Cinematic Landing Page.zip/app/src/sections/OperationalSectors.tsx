import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Plus } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const sectors = [
  {
    name: 'Endpoint Defense',
    description:
      'AI-powered endpoint protection that detects and neutralizes threats at the device level. Real-time behavioral analysis, automated threat response, and zero-touch remediation for your entire endpoint fleet.',
  },
  {
    name: 'Cloud Infra Hardening',
    description:
      'Comprehensive security architecture for AWS, Azure, and GCP environments. We implement defense-in-depth strategies, IAM optimization, network segmentation, and continuous compliance monitoring.',
  },
  {
    name: 'Adversary Simulation',
    description:
      'Red team exercises that mirror real-world attack patterns. Our ethical hackers probe your defenses using the same techniques as advanced persistent threats, revealing vulnerabilities before adversaries do.',
  },
  {
    name: 'Zero-Trust Architecture',
    description:
      'Implement never-trust, always-verify frameworks. Micro-segmentation, identity-centric access controls, and continuous authentication ensure that every access request is validated in real-time.',
  },
];

export default function OperationalSectors() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    if (titleRef.current) {
      gsap.fromTo(
        titleRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: titleRef.current,
            start: 'top 80%',
          },
        }
      );
    }
  }, []);

  return (
    <section
      ref={sectionRef}
      id="sectors"
      data-nav-light
      style={{
        backgroundColor: '#f1f1ef',
        padding: '160px 24px',
      }}
    >
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <h2
          ref={titleRef}
          className="font-display font-medium"
          style={{
            fontSize: '40px',
            lineHeight: 1.1,
            color: '#151515',
            marginBottom: '80px',
          }}
        >
          Operational Sectors
        </h2>
        <div>
          {sectors.map((sector, i) => (
            <SectorRow key={i} sector={sector} />
          ))}
        </div>
      </div>
    </section>
  );
}

function SectorRow({
  sector,
}: {
  sector: { name: string; description: string };
}) {
  const rowRef = useRef<HTMLDivElement>(null);

  return (
    <div
      ref={rowRef}
      className="group cursor-pointer"
      style={{
        borderTop: '1px solid #c4cec5',
        padding: '32px 0',
        transition: 'none',
      }}
      onMouseEnter={(e) => {
        const el = e.currentTarget;
        el.style.backgroundColor = '#151515';
        el.style.marginLeft = '-24px';
        el.style.marginRight = '-24px';
        el.style.paddingLeft = '24px';
        el.style.paddingRight = '24px';
      }}
      onMouseLeave={(e) => {
        const el = e.currentTarget;
        el.style.backgroundColor = 'transparent';
        el.style.marginLeft = '0';
        el.style.marginRight = '0';
        el.style.paddingLeft = '0';
        el.style.paddingRight = '0';
      }}
    >
      <div className="flex items-start justify-between gap-8">
        <div className="flex-shrink-0" style={{ width: '280px' }}>
          <h3
            className="font-display font-medium group-hover:text-[#f1f1ef]"
            style={{
              fontSize: '28px',
              lineHeight: 1.2,
              color: '#151515',
              transition: 'none',
            }}
          >
            {sector.name}
          </h3>
        </div>
        <div className="flex-grow" style={{ maxWidth: '600px' }}>
          <p
            className="font-body group-hover:text-[#c4cec5]"
            style={{
              fontSize: '18px',
              lineHeight: 1.4,
              color: '#151515',
              opacity: 0.7,
              transition: 'none',
            }}
          >
            {sector.description}
          </p>
        </div>
        <div className="flex-shrink-0 flex items-center justify-center" style={{ width: '48px', height: '48px' }}>
          <Plus
            size={24}
            className="group-hover:text-[#26ff6a]"
            style={{ color: '#151515', transition: 'none' }}
          />
        </div>
      </div>
    </div>
  );
}
