import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowUpRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const cases = [
  {
    sector: 'Financial Services',
    title: 'Supply chain compromise neutralised in 47 minutes',
    summary:
      'A mid-size wealth management firm in North Sydney faced a sophisticated supply chain attack targeting their document management system. Sentri\'s AI detected anomalous PowerShell execution at 02:14 and isolated the affected endpoint before lateral movement could begin.',
    outcome: 'Zero data exfiltration. Full containment in 47 minutes. Client operational within 4 hours.',
  },
  {
    sector: 'Healthcare',
    title: 'Ransomware deployment halted at encryption stage',
    summary:
      'A multi-clinic medical practice in the Eastern Suburbs experienced a phishing-initiated ransomware attack. Sentri\'s behavioral engine identified the encryption routine signature within 12 seconds of first execution, triggering automated isolation.',
    outcome: '97% of systems protected. Zero patient data compromised. No ransom paid. Recovery completed in 6 hours.',
  },
  {
    sector: 'Professional Services',
    title: 'Credential stuffing campaign detected and blocked',
    summary:
      'A commercial law firm experienced a sustained credential stuffing attack against their cloud email platform. Sentri\'s identity threat detection identified the pattern, enforced step-up authentication, and blocked 14,000+ malicious login attempts over 72 hours.',
    outcome: 'All accounts secured. No unauthorised access achieved. Attacker infrastructure mapped and reported to ACSC.',
  },
];

export default function CaseStudies() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    if (titleRef.current) {
      gsap.fromTo(
        titleRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: titleRef.current,
            start: 'top 80%',
          },
        }
      );
    }

    if (sectionRef.current) {
      const items = sectionRef.current.querySelectorAll('.case-item');
      gsap.fromTo(
        items,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          stagger: 0.2,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
          },
        }
      );
    }
  }, []);

  return (
    <section
      ref={sectionRef}
      style={{
        backgroundColor: '#000000',
        padding: '160px 24px',
      }}
    >
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <div className="flex items-center gap-4" style={{ marginBottom: '16px' }}>
          <span
            className="font-mono"
            style={{
              fontSize: '14px',
              fontWeight: 400,
              letterSpacing: '0.5px',
              textTransform: 'uppercase',
              color: '#26ff6a',
            }}
          >
            Engagements
          </span>
          <div style={{ flex: 1, height: '1px', backgroundColor: '#c4cec5', opacity: 0.15 }} />
        </div>
        <h2
          ref={titleRef}
          className="font-display font-medium"
          style={{
            fontSize: '40px',
            lineHeight: 1.1,
            color: '#f1f1ef',
            marginBottom: '80px',
          }}
        >
          Selected case studies
        </h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
          {cases.map((c, i) => (
            <CaseItem key={i} caseStudy={c} />
          ))}
        </div>
      </div>
    </section>
  );
}

function CaseItem({
  caseStudy,
}: {
  caseStudy: {
    sector: string;
    title: string;
    summary: string;
    outcome: string;
  };
}) {
  return (
    <div
      className="case-item group cursor-pointer"
      style={{
        borderTop: '1px solid rgba(196, 206, 197, 0.1)',
        padding: '48px 0',
      }}
    >
      <div className="flex items-start justify-between gap-8">
        <div className="flex-grow">
          <span
            className="font-mono"
            style={{
              fontSize: '12px',
              fontWeight: 400,
              letterSpacing: '0.5px',
              textTransform: 'uppercase',
              color: '#26ff6a',
              display: 'block',
              marginBottom: '16px',
            }}
          >
            {caseStudy.sector}
          </span>
          <h3
            className="font-display font-medium"
            style={{
              fontSize: '28px',
              lineHeight: 1.2,
              color: '#f1f1ef',
              marginBottom: '16px',
            }}
          >
            {caseStudy.title}
          </h3>
          <p
            className="font-body"
            style={{
              fontSize: '16px',
              lineHeight: 1.5,
              color: '#c4cec5',
              opacity: 0.6,
              maxWidth: '700px',
              marginBottom: '16px',
            }}
          >
            {caseStudy.summary}
          </p>
          <p
            className="font-body"
            style={{
              fontSize: '14px',
              lineHeight: 1.4,
              color: '#26ff6a',
              opacity: 0.8,
            }}
          >
            {caseStudy.outcome}
          </p>
        </div>
        <div
          className="flex-shrink-0 flex items-center justify-center group-hover:bg-[#26ff6a]"
          style={{
            width: '48px',
            height: '48px',
            border: '1px solid rgba(196, 206, 197, 0.2)',
            transition: 'none',
          }}
        >
          <ArrowUpRight
            size={20}
            className="group-hover:text-[#000000]"
            style={{ color: '#c4cec5', transition: 'none' }}
          />
        </div>
      </div>
    </div>
  );
}
