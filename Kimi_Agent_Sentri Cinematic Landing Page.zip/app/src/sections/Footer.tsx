export default function Footer() {
  return (
    <footer
      style={{
        backgroundColor: '#000000',
        padding: '80px 24px 40px',
        borderTop: '1px solid rgba(196, 206, 197, 0.08)',
      }}
    >
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        {/* Massive wordmark */}
        <div style={{ marginBottom: '80px' }}>
          <span
            className="font-display font-medium"
            style={{
              fontSize: 'clamp(80px, 15vw, 200px)',
              lineHeight: 0.9,
              color: '#f1f1ef',
              opacity: 0.06,
              display: 'block',
              letterSpacing: '-0.02em',
            }}
          >
            Sentri
          </span>
        </div>

        {/* Links grid */}
        <div
          className="grid grid-cols-2 md:grid-cols-4"
          style={{ gap: '32px', marginBottom: '80px' }}
        >
          <div>
            <h4
              className="font-mono"
              style={{
                fontSize: '12px',
                fontWeight: 400,
                letterSpacing: '0.5px',
                textTransform: 'uppercase',
                color: '#c4cec5',
                opacity: 0.4,
                marginBottom: '16px',
              }}
            >
              Services
            </h4>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {['Endpoint Defense', 'Cloud Hardening', 'Adversary Simulation', 'Zero-Trust'].map((item) => (
                <li key={item}>
                  <a
                    href="#"
                    className="font-body"
                    style={{
                      fontSize: '14px',
                      color: '#c4cec5',
                      opacity: 0.6,
                      textDecoration: 'none',
                    }}
                    onMouseEnter={(e) => { (e.target as HTMLElement).style.opacity = '1'; }}
                    onMouseLeave={(e) => { (e.target as HTMLElement).style.opacity = '0.6'; }}
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4
              className="font-mono"
              style={{
                fontSize: '12px',
                fontWeight: 400,
                letterSpacing: '0.5px',
                textTransform: 'uppercase',
                color: '#c4cec5',
                opacity: 0.4,
                marginBottom: '16px',
              }}
            >
              Compliance
            </h4>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {['Privacy Act', 'Essential Eight', 'ISO 27001', 'SOC 2'].map((item) => (
                <li key={item}>
                  <a
                    href="#"
                    className="font-body"
                    style={{
                      fontSize: '14px',
                      color: '#c4cec5',
                      opacity: 0.6,
                      textDecoration: 'none',
                    }}
                    onMouseEnter={(e) => { (e.target as HTMLElement).style.opacity = '1'; }}
                    onMouseLeave={(e) => { (e.target as HTMLElement).style.opacity = '0.6'; }}
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4
              className="font-mono"
              style={{
                fontSize: '12px',
                fontWeight: 400,
                letterSpacing: '0.5px',
                textTransform: 'uppercase',
                color: '#c4cec5',
                opacity: 0.4,
                marginBottom: '16px',
              }}
            >
              Company
            </h4>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {['About', 'Careers', 'Contact', 'Blog'].map((item) => (
                <li key={item}>
                  <a
                    href="#"
                    className="font-body"
                    style={{
                      fontSize: '14px',
                      color: '#c4cec5',
                      opacity: 0.6,
                      textDecoration: 'none',
                    }}
                    onMouseEnter={(e) => { (e.target as HTMLElement).style.opacity = '1'; }}
                    onMouseLeave={(e) => { (e.target as HTMLElement).style.opacity = '0.6'; }}
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4
              className="font-mono"
              style={{
                fontSize: '12px',
                fontWeight: 400,
                letterSpacing: '0.5px',
                textTransform: 'uppercase',
                color: '#c4cec5',
                opacity: 0.4,
                marginBottom: '16px',
              }}
            >
              Connect
            </h4>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {['LinkedIn', 'Twitter/X', 'GitHub', 'ACSC Partner'].map((item) => (
                <li key={item}>
                  <a
                    href="#"
                    className="font-body"
                    style={{
                      fontSize: '14px',
                      color: '#c4cec5',
                      opacity: 0.6,
                      textDecoration: 'none',
                    }}
                    onMouseEnter={(e) => { (e.target as HTMLElement).style.opacity = '1'; }}
                    onMouseLeave={(e) => { (e.target as HTMLElement).style.opacity = '0.6'; }}
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div
          className="flex flex-col md:flex-row items-start md:items-center justify-between"
          style={{
            borderTop: '1px solid rgba(196, 206, 197, 0.08)',
            paddingTop: '24px',
            gap: '16px',
          }}
        >
          <span
            className="font-mono"
            style={{
              fontSize: '12px',
              color: '#c4cec5',
              opacity: 0.3,
            }}
          >
            &copy; 2025 Sentri Cybersecurity Pty Ltd. All rights reserved.
          </span>
          <div className="flex items-center" style={{ gap: '24px' }}>
            {['Privacy Policy', 'SLA', 'Terms of Service'].map((item) => (
              <a
                key={item}
                href="#"
                className="font-mono"
                style={{
                  fontSize: '12px',
                  color: '#c4cec5',
                  opacity: 0.3,
                  textDecoration: 'none',
                }}
                onMouseEnter={(e) => { (e.target as HTMLElement).style.opacity = '0.6'; }}
                onMouseLeave={(e) => { (e.target as HTMLElement).style.opacity = '0.3'; }}
              >
                {item}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
