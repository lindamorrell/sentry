import { useRef, useEffect, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const navLinks = [
  { label: 'Sectors', href: '#sectors' },
  { label: 'Methodology', href: '#methodology' },
  { label: 'Response', href: '#response' },
  { label: 'Compliance', href: '#compliance' },
  { label: 'Contact', href: '#contact' },
];

export default function Navigation() {
  const navRef = useRef<HTMLElement>(null);
  const [isLight, setIsLight] = useState(false);

  useEffect(() => {
    // Check if nav overlaps with light sections
    const lightSections = document.querySelectorAll('[data-nav-light]');
    if (!lightSections.length) return;

    const triggers: ScrollTrigger[] = [];
    lightSections.forEach((section) => {
      const trigger = ScrollTrigger.create({
        trigger: section,
        start: 'top top',
        end: 'bottom top',
        onEnter: () => setIsLight(true),
        onLeave: () => setIsLight(false),
        onEnterBack: () => setIsLight(true),
        onLeaveBack: () => setIsLight(false),
      });
      triggers.push(trigger);
    });

    return () => {
      triggers.forEach((t) => t.kill());
    };
  }, []);

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const el = document.querySelector(href);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav
      ref={navRef}
      className="fixed top-0 left-0 w-full z-50 flex items-center justify-between"
      style={{ padding: '24px', transition: 'color 0.3s ease' }}
    >
      <a
        href="#"
        className="font-mono font-semibold tracking-wide"
        style={{
          fontSize: '18px',
          color: isLight ? '#151515' : '#c4cec5',
          textDecoration: 'none',
        }}
        onClick={(e) => {
          e.preventDefault();
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      >
        Sentri
      </a>
      <div className="hidden md:flex items-center" style={{ gap: '32px' }}>
        {navLinks.map((link) => (
          <a
            key={link.label}
            href={link.href}
            onClick={(e) => handleClick(e, link.href)}
            className="font-body relative"
            style={{
              fontSize: '14px',
              fontWeight: 400,
              letterSpacing: '0.5px',
              textTransform: 'uppercase',
              color: isLight ? '#151515' : '#c4cec5',
              textDecoration: 'none',
              transition: 'opacity 0.2s ease',
            }}
            onMouseEnter={(e) => { (e.target as HTMLElement).style.opacity = '0.5'; }}
            onMouseLeave={(e) => { (e.target as HTMLElement).style.opacity = '1'; }}
          >
            {link.label}
          </a>
        ))}
      </div>
    </nav>
  );
}
