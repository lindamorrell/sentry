import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Search, Scan, AlertTriangle, Crosshair, FileText } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const steps = [
  {
    number: '01',
    icon: Search,
    title: 'Reconnaissance',
    description:
      'We map your entire attack surface — internal networks, cloud assets, third-party integrations, and exposed services. Every endpoint, API, and access point is catalogued and risk-scored against the MITRE ATT&CK framework.',
  },
  {
    number: '02',
    icon: Scan,
    title: 'Vulnerability Assessment',
    description:
      'Automated scanning combined with manual penetration testing identifies configuration weaknesses, unpatched systems, and logic flaws. We prioritise findings by exploitability and business impact, not CVSS score alone.',
  },
  {
    number: '03',
    icon: AlertTriangle,
    title: 'Threat Detection',
    description:
      'Our AI-driven SIEM ingests telemetry from every layer of your stack. Behavioral analytics establish baselines for every user and entity, flagging deviations that signature-based tools miss.',
  },
  {
    number: '04',
    icon: Crosshair,
    title: 'Response & Containment',
    description:
      'When a threat is confirmed, automated playbooks execute within seconds — isolating compromised assets, blocking malicious IPs, and preserving forensic evidence for investigation.',
  },
  {
    number: '05',
    icon: FileText,
    title: 'Reporting & Remediation',
    description:
      'Every engagement produces actionable intelligence: executive summaries for leadership, technical findings for engineering, and remediation roadmaps with clear priorities and timelines.',
  },
];

export default function Methodology() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    if (titleRef.current) {
      gsap.fromTo(
        titleRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: titleRef.current,
            start: 'top 80%',
          },
        }
      );
    }

    if (sectionRef.current) {
      const items = sectionRef.current.querySelectorAll('.method-step');
      gsap.fromTo(
        items,
        { opacity: 0, x: -20 },
        {
          opacity: 1,
          x: 0,
          duration: 0.5,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
          },
        }
      );
    }
  }, []);

  return (
    <section
      ref={sectionRef}
      id="methodology"
      style={{
        backgroundColor: '#151515',
        padding: '160px 24px',
      }}
    >
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <div className="flex items-center gap-4" style={{ marginBottom: '16px' }}>
          <span
            className="font-mono"
            style={{
              fontSize: '14px',
              fontWeight: 400,
              letterSpacing: '0.5px',
              textTransform: 'uppercase',
              color: '#26ff6a',
            }}
          >
            Methodology
          </span>
          <div style={{ flex: 1, height: '1px', backgroundColor: '#c4cec5', opacity: 0.15 }} />
        </div>
        <h2
          ref={titleRef}
          className="font-display font-medium"
          style={{
            fontSize: '40px',
            lineHeight: 1.1,
            color: '#f1f1ef',
            marginBottom: '80px',
          }}
        >
          Our threat methodology
        </h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
          {steps.map((step, i) => (
            <div
              key={i}
              className="method-step"
              style={{
                borderTop: '1px solid rgba(196, 206, 197, 0.1)',
                padding: '40px 0',
                display: 'grid',
                gridTemplateColumns: '80px 60px 1fr',
                gap: '32px',
                alignItems: 'start',
              }}
            >
              <span
                className="font-mono"
                style={{
                  fontSize: '14px',
                  fontWeight: 400,
                  color: '#c4cec5',
                  opacity: 0.4,
                }}
              >
                {step.number}
              </span>
              <step.icon size={24} style={{ color: '#26ff6a', marginTop: '2px' }} />
              <div>
                <h3
                  className="font-display font-medium"
                  style={{
                    fontSize: '28px',
                    lineHeight: 1.2,
                    color: '#f1f1ef',
                    marginBottom: '12px',
                  }}
                >
                  {step.title}
                </h3>
                <p
                  className="font-body"
                  style={{
                    fontSize: '16px',
                    lineHeight: 1.5,
                    color: '#c4cec5',
                    opacity: 0.6,
                    maxWidth: '600px',
                  }}
                >
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
