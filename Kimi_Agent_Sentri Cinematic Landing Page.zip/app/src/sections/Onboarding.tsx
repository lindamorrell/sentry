import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Phone, ClipboardList, Rocket, Shield } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const phases = [
  {
    icon: Phone,
    title: 'Discovery Call',
    description: 'A 30-minute confidential briefing to understand your environment, compliance requirements, and threat landscape. No sales pitch — just threat intelligence.',
  },
  {
    icon: ClipboardList,
    title: 'Security Assessment',
    description: 'We conduct a comprehensive baseline assessment of your current posture — vulnerability scans, policy reviews, and architecture analysis — delivered as a prioritised roadmap.',
  },
  {
    icon: Rocket,
    title: 'Deployment',
    description: 'Agent deployment across endpoints, SIEM integration, and playbook configuration. Most clients are fully operational within 72 hours. No disruption to business operations.',
  },
  {
    icon: Shield,
    title: 'Continuous Protection',
    description: '24/7 monitoring with AI-driven detection and human analyst validation. Monthly executive reports, quarterly threat briefings, and on-demand incident response.',
  },
];

export default function Onboarding() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    if (titleRef.current) {
      gsap.fromTo(
        titleRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: titleRef.current,
            start: 'top 80%',
          },
        }
      );
    }

    if (sectionRef.current) {
      const items = sectionRef.current.querySelectorAll('.onboard-phase');
      gsap.fromTo(
        items,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.5,
          stagger: 0.12,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
          },
        }
      );
    }
  }, []);

  return (
    <section
      ref={sectionRef}
      data-nav-light
      style={{
        backgroundColor: '#f1f1ef',
        padding: '160px 24px',
      }}
    >
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <div className="flex items-center gap-4" style={{ marginBottom: '16px' }}>
          <span
            className="font-mono"
            style={{
              fontSize: '14px',
              fontWeight: 400,
              letterSpacing: '0.5px',
              textTransform: 'uppercase',
              color: '#151515',
              opacity: 0.5,
            }}
          >
            Onboarding
          </span>
          <div style={{ flex: 1, height: '1px', backgroundColor: '#151515', opacity: 0.1 }} />
        </div>
        <h2
          ref={titleRef}
          className="font-display font-medium"
          style={{
            fontSize: '40px',
            lineHeight: 1.1,
            color: '#151515',
            marginBottom: '80px',
          }}
        >
          Client onboarding
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4" style={{ gap: '32px' }}>
          {phases.map((phase, i) => (
            <div
              key={i}
              className="onboard-phase"
              style={{
                border: '1px solid rgba(21, 21, 21, 0.1)',
                padding: '32px 24px',
                backgroundColor: 'rgba(255, 255, 255, 0.4)',
              }}
            >
              <div
                className="flex items-center justify-center"
                style={{
                  width: '48px',
                  height: '48px',
                  border: '1px solid #151515',
                  marginBottom: '24px',
                }}
              >
                <phase.icon size={24} style={{ color: '#151515' }} />
              </div>
              <h3
                className="font-display font-medium"
                style={{
                  fontSize: '22px',
                  lineHeight: 1.2,
                  color: '#151515',
                  marginBottom: '12px',
                }}
              >
                {phase.title}
              </h3>
              <p
                className="font-body"
                style={{
                  fontSize: '15px',
                  lineHeight: 1.5,
                  color: '#151515',
                  opacity: 0.6,
                }}
              >
                {phase.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
