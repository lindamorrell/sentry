import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ShieldCheck, Lock, FileCheck } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const frameworks = [
  {
    icon: Lock,
    name: 'Australian Privacy Act',
    code: 'Privacy Act 1988 (Cth)',
    description:
      'Full compliance with the Privacy Act and Australian Privacy Principles (APPs). We ensure your organisation meets all 13 APPs, including APP 11 security obligations, with documented data handling procedures and breach notification protocols.',
  },
  {
    icon: ShieldCheck,
    name: 'Essential Eight',
    code: 'ACSC Mitigation Strategies',
    description:
      'Implementation and validation of all eight Australian Cyber Security Centre mitigation strategies. From application control to multi-factor authentication, we harden your environment against the most common attack vectors targeting Australian organisations.',
  },
  {
    icon: FileCheck,
    name: 'ISO 27001',
    code: 'ISMS Certification',
    description:
      'End-to-end Information Security Management System (ISMS) implementation aligned with ISO/IEC 27001:2022. Risk assessment, control implementation, internal audit, and certification support — we guide you through every stage of the journey.',
  },
];

export default function Compliance() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (titleRef.current) {
      gsap.fromTo(
        titleRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: titleRef.current,
            start: 'top 80%',
          },
        }
      );
    }

    if (cardsRef.current) {
      const cards = cardsRef.current.querySelectorAll('.compliance-card');
      gsap.fromTo(
        cards,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          stagger: 0.15,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: cardsRef.current,
            start: 'top 75%',
          },
        }
      );
    }
  }, []);

  return (
    <section
      ref={sectionRef}
      id="compliance"
      style={{
        backgroundColor: '#151515',
        padding: '160px 24px',
      }}
    >
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <div className="flex items-center gap-4" style={{ marginBottom: '16px' }}>
          <span
            className="font-mono"
            style={{
              fontSize: '14px',
              fontWeight: 400,
              letterSpacing: '0.5px',
              textTransform: 'uppercase',
              color: '#26ff6a',
            }}
          >
            Compliance
          </span>
          <div style={{ flex: 1, height: '1px', backgroundColor: '#c4cec5', opacity: 0.2 }} />
        </div>
        <h2
          ref={titleRef}
          className="font-display font-medium"
          style={{
            fontSize: '40px',
            lineHeight: 1.1,
            color: '#f1f1ef',
            marginBottom: '80px',
          }}
        >
          Australian regulatory coverage
        </h2>
        <div ref={cardsRef} className="grid grid-cols-1 md:grid-cols-3" style={{ gap: '32px' }}>
          {frameworks.map((fw, i) => (
            <div
              key={i}
              className="compliance-card"
              style={{
                border: '1px solid rgba(196, 206, 197, 0.15)',
                padding: '40px 32px',
                backgroundColor: 'rgba(0, 0, 0, 0.3)',
              }}
            >
              <fw.icon size={32} style={{ color: '#26ff6a', marginBottom: '24px' }} />
              <span
                className="font-mono"
                style={{
                  fontSize: '12px',
                  fontWeight: 400,
                  letterSpacing: '0.5px',
                  textTransform: 'uppercase',
                  color: '#c4cec5',
                  opacity: 0.5,
                  display: 'block',
                  marginBottom: '8px',
                }}
              >
                {fw.code}
              </span>
              <h3
                className="font-display font-medium"
                style={{
                  fontSize: '28px',
                  lineHeight: 1.2,
                  color: '#f1f1ef',
                  marginBottom: '16px',
                }}
              >
                {fw.name}
              </h3>
              <p
                className="font-body"
                style={{
                  fontSize: '16px',
                  lineHeight: 1.5,
                  color: '#c4cec5',
                  opacity: 0.7,
                }}
              >
                {fw.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
