import { useRef, useEffect } from 'react';
import * as THREE from 'three';

const vertexShader = `
void main() {
  gl_Position = vec4(position, 1.0);
}
`;

const fragmentShader = `
precision highp float;

uniform float u_time;
uniform vec2 u_resolution;
uniform vec2 u_mouse;
uniform float u_fluid;

float hash(vec2 p) {
  return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

float noise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  float a = hash(i);
  float b = hash(i + vec2(1.0, 0.0));
  float c = hash(i + vec2(0.0, 1.0));
  float d = hash(i + vec2(1.0, 1.0));
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
  float val = 0.0;
  float amp = 0.5;
  float freq = 1.0;
  for (int i = 0; i < 6; i++) {
    val += amp * noise(p * freq);
    freq *= 2.03;
    amp *= 0.49;
    p += vec2(1.7, 9.2);
  }
  return val;
}

float fluidFbm(vec2 p) {
  return fbm(p + fbm(p + fbm(p)));
}

vec2 rot(vec2 p, float a) {
  float c = cos(a);
  float s = sin(a);
  return vec2(p.x * c - p.y * s, p.x * s + p.y * c);
}

void main() {
  vec2 uv = gl_FragCoord.xy / u_resolution;
  vec2 aspect = vec2(u_resolution.x / u_resolution.y, 1.0);
  vec2 p = (uv - 0.5) * aspect;

  vec2 mouseVel = vec2(0.0);
  vec2 mousePos = vec2(0.0);
  if (u_mouse.x > 0.0) {
    mousePos = (u_mouse / u_resolution - 0.5) * aspect;
    mouseVel = (u_mouse - vec2(0.5)) / u_resolution;
  }

  float t = u_time * 0.2;
  vec2 q = vec2(0.0);
  q.x = fluidFbm(p + vec2(t * 0.3, t * 0.2));
  q.y = fluidFbm(p + vec2(1.8 + t * 0.2, 6.2 + t * 0.15));

  float fluid = fluidFbm(p + q * u_fluid);
  p += mouseVel * 0.02 / (length(p - mousePos) + 0.1);

  vec2 r = vec2(0.0);
  r.x = fluidFbm(p + 1.7 + vec2(t * 0.25, 3.2 + t * 0.18));
  r.y = fluidFbm(p + 9.2 + vec2(4.3 + t * 0.2, 1.4 + t * 0.22));

  fluid = fluidFbm(p + r * 0.7);
  p = rot(p - mousePos, fluid * 2.0 + t) + mousePos;

  vec3 col = vec3(0.04, 0.04, 0.04);
  col.r += 0.02;
  col.r -= 0.01;
  col.r += p.x;
  col.g += 0.03 + p.y * 0.02;

  vec3 fluidColor = vec3(0.01, 0.08, 0.02);
  vec3 fluidColor2 = vec3(0.2, 0.9, 0.35);

  float fluidGradient = smoothstep(0.1, 0.8, fluid) * (1.0 - smoothstep(0.5, 0.9, fluid));
  col = mix(col, mix(fluidColor, fluidColor2, fluid), fluidGradient * (0.5 + 0.5 * r.x));

  float grain = hash(uv * u_resolution + fract(u_time) * 100.0);
  col *= 0.95 + 0.05 * grain;

  if (u_mouse.x > 0.0) {
    float md = length(p - mousePos);
    float mGlow = exp(-md * md * 4.0);
    vec3 mColor = vec3(0.0, 0.5, 0.1);
    col += mColor * mGlow * 0.2;
    float mDistort = sin(md * 20.0 - u_time * 2.0) * 0.5 + 0.5;
    col += vec3(0.05, 0.25, 0.05) * mDistort * mGlow * 0.3;
  }

  col = clamp(col, 0.0, 1.0);
  gl_FragColor = vec4(col, 1.0);
}
`;

export default function HeroFluid() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const animationRef = useRef<number>(0);
  const mouseRef = useRef(new THREE.Vector2(-1, -1));
  const prevMouseRef = useRef(new THREE.Vector2(-1, -1));
  const mouseVelRef = useRef(new THREE.Vector2(0, 0));
  const smoothMouseRef = useRef(new THREE.Vector2(-1, -1));
  const targetMouseRef = useRef(new THREE.Vector2(-1, -1));

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: false,
      powerPreference: 'high-performance',
    });
    rendererRef.current = renderer;

    const pixelRatio = Math.min(window.devicePixelRatio, 1.5);
    renderer.setPixelRatio(pixelRatio);
    renderer.setSize(window.innerWidth, window.innerHeight);

    const scene = new THREE.Scene();
    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);

    const uniforms = {
      u_time: { value: 0.0 },
      u_resolution: { value: new THREE.Vector2(window.innerWidth * pixelRatio, window.innerHeight * pixelRatio) },
      u_mouse: { value: new THREE.Vector2(-1, -1) },
      u_fluid: { value: 1.0 },
    };

    const material = new THREE.ShaderMaterial({
      vertexShader,
      fragmentShader,
      uniforms,
    });

    const geometry = new THREE.PlaneGeometry(2, 2);
    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    const handleMouseMove = (e: MouseEvent) => {
      prevMouseRef.current.copy(mouseRef.current);
      mouseRef.current.set(e.clientX * pixelRatio, (window.innerHeight - e.clientY) * pixelRatio);
      mouseVelRef.current.set(
        mouseRef.current.x - prevMouseRef.current.x,
        mouseRef.current.y - prevMouseRef.current.y
      );
      targetMouseRef.current.set(e.clientX * pixelRatio, (window.innerHeight - e.clientY) * pixelRatio);
    };

    window.addEventListener('mousemove', handleMouseMove);

    const handleResize = () => {
      renderer.setSize(window.innerWidth, window.innerHeight);
      uniforms.u_resolution.value.set(window.innerWidth * pixelRatio, window.innerHeight * pixelRatio);
    };

    window.addEventListener('resize', handleResize);

    const render = (time: number) => {
      smoothMouseRef.current.lerp(targetMouseRef.current, 0.08);

      uniforms.u_time.value = time * 0.001;
      uniforms.u_resolution.value.set(window.innerWidth * pixelRatio, window.innerHeight * pixelRatio);
      uniforms.u_mouse.value.set(smoothMouseRef.current.x, smoothMouseRef.current.y);
      uniforms.u_fluid.value = 1.0 + Math.sqrt(mouseVelRef.current.x * mouseVelRef.current.x + mouseVelRef.current.y * mouseVelRef.current.y) * 0.3;

      mouseVelRef.current.x *= 0.85;
      mouseVelRef.current.y *= 0.85;

      renderer.render(scene, camera);
      animationRef.current = requestAnimationFrame(render);
    };

    animationRef.current = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationRef.current);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      geometry.dispose();
      material.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        zIndex: 1,
      }}
    />
  );
}
