import { useRef, useEffect } from 'react';
import * as THREE from 'three';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const vertexShader = `
void main() {
  gl_Position = vec4(position, 1.0);
}
`;

const fragmentShader = `
precision highp float;

uniform float u_time;
uniform vec2 u_resolution;
uniform vec3 u_col1;
uniform vec3 u_col2;
uniform vec3 u_col3;
uniform vec3 u_col4;

float hash(vec2 p) {
  return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

float noise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  float a = hash(i);
  float b = hash(i + vec2(1.0, 0.0));
  float c = hash(i + vec2(0.0, 1.0));
  float d = hash(i + vec2(1.0, 1.0));
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
  float val = 0.0;
  float amp = 0.5;
  float freq = 1.0;
  for (int i = 0; i < 6; i++) {
    val += amp * noise(p * freq);
    freq *= 2.03;
    amp *= 0.49;
    p += vec2(1.7, 9.2);
  }
  return val;
}

float fluidFbm(vec2 p) {
  return fbm(p + fbm(p + fbm(p)));
}

vec2 rot(vec2 p, float a) {
  float c = cos(a);
  float s = sin(a);
  return vec2(p.x * c - p.y * s, p.x * s + p.y * c);
}

void main() {
  vec2 uv = gl_FragCoord.xy / u_resolution;
  vec2 aspect = vec2(u_resolution.x / u_resolution.y, 1.0);
  vec2 p = (uv - 0.5) * aspect;

  float t = u_time * 0.2;
  vec2 q = vec2(0.0);
  q.x = fluidFbm(p + vec2(t * 0.3, t * 0.2));
  q.y = fluidFbm(p + vec2(1.8 + t * 0.2, 6.2 + t * 0.15));

  float fluid = fluidFbm(p + q * 1.5);

  vec2 r = vec2(0.0);
  r.x = fluidFbm(p + 1.7 + vec2(t * 0.25, 3.2 + t * 0.18));
  r.y = fluidFbm(p + 9.2 + vec2(4.3 + t * 0.2, 1.4 + t * 0.22));

  fluid = fluidFbm(p + r * 0.7);

  float colorMix = fbm(p * 1.5 + r);
  vec3 col = u_col1;
  col = mix(col, u_col2, colorMix);

  float highlight = smoothstep(0.4, 0.8, fluid);
  col = mix(col, u_col3, highlight * r.x);

  float bright = smoothstep(0.6, 0.9, fluid);
  col = mix(col, u_col4, bright);

  col *= 0.95 + 0.05 * hash(uv * u_resolution + fract(u_time) * 100.0);

  col = clamp(col, 0.0, 1.0);
  gl_FragColor = vec4(col, 1.0);
}
`;

export default function StateShiftingFluid() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const animationRef = useRef<number>(0);
  const timelineRef = useRef<gsap.core.Timeline | null>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const canvas = canvasRef.current;
    if (!section || !canvas) return;

    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: false,
      powerPreference: 'high-performance',
    });
    rendererRef.current = renderer;

    const pixelRatio = Math.min(window.devicePixelRatio, 1.5);
    renderer.setPixelRatio(pixelRatio);
    renderer.setSize(window.innerWidth, window.innerHeight);

    const scene = new THREE.Scene();
    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);

    const uniforms = {
      u_time: { value: 0.0 },
      u_resolution: { value: new THREE.Vector2(window.innerWidth * pixelRatio, window.innerHeight * pixelRatio) },
      u_col1: { value: new THREE.Vector3(0.04, 0.04, 0.04) },
      u_col2: { value: new THREE.Vector3(0.10, 0.10, 0.10) },
      u_col3: { value: new THREE.Vector3(0.05, 0.35, 0.15) },
      u_col4: { value: new THREE.Vector3(0.15, 0.80, 0.42) },
    };

    const material = new THREE.ShaderMaterial({
      vertexShader,
      fragmentShader,
      uniforms,
    });

    const geometry = new THREE.PlaneGeometry(2, 2);
    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    const sageState = { c1r: 0.04, c1g: 0.04, c1b: 0.04, c2r: 0.10, c2g: 0.10, c2b: 0.10, c3r: 0.05, c3g: 0.35, c3b: 0.15, c4r: 0.15, c4g: 0.80, c4b: 0.42 };
    const alertState = { c1r: 0.04, c1g: 0.04, c1b: 0.04, c2r: 0.20, c2g: 0.05, c2b: 0.02, c3r: 0.80, c3g: 0.20, c3b: 0.05, c4r: 1.0, c4g: 0.26, c4b: 0.18 };
    const voidState = { c1r: 0.01, c1g: 0.01, c1b: 0.01, c2r: 0.05, c2g: 0.05, c2b: 0.05, c3r: 0.1, c3g: 0.1, c3b: 0.1, c4r: 0.0, c4g: 0.5, c4b: 0.1 };

    const driver = { ...sageState };

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: section,
        start: 'top top',
        end: '+=150%',
        scrub: true,
        pin: true,
      },
    });

    tl.to(driver, { ...alertState, ease: 'none' });
    tl.to(driver, { ...voidState, ease: 'none' });

    timelineRef.current = tl;

    const handleResize = () => {
      renderer.setSize(window.innerWidth, window.innerHeight);
      uniforms.u_resolution.value.set(window.innerWidth * pixelRatio, window.innerHeight * pixelRatio);
    };

    window.addEventListener('resize', handleResize);

    const render = (time: number) => {
      uniforms.u_time.value = time * 0.001;
      uniforms.u_resolution.value.set(window.innerWidth * pixelRatio, window.innerHeight * pixelRatio);

      uniforms.u_col1.value.set(driver.c1r, driver.c1g, driver.c1b);
      uniforms.u_col2.value.set(driver.c2r, driver.c2g, driver.c2b);
      uniforms.u_col3.value.set(driver.c3r, driver.c3g, driver.c3b);
      uniforms.u_col4.value.set(driver.c4r, driver.c4g, driver.c4b);

      renderer.render(scene, camera);
      animationRef.current = requestAnimationFrame(render);
    };

    animationRef.current = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationRef.current);
      window.removeEventListener('resize', handleResize);
      tl.kill();
      geometry.dispose();
      material.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <section ref={sectionRef} className="relative" style={{ height: '150vh' }}>
      <div
        className="sticky top-0 w-full overflow-hidden"
        style={{ height: '100vh' }}
      >
        <canvas
          ref={canvasRef}
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            zIndex: 1,
          }}
        />
        {/* Floating text blocks */}
        <div
          className="absolute z-10 flex items-center justify-center"
          style={{ top: '20%', left: '50%', transform: 'translateX(-50%)' }}
        >
          <h2
            className="font-display text-center font-medium"
            style={{
              fontSize: '40px',
              lineHeight: 1.1,
              color: '#c4cec5',
              textShadow: '0px 0px 4px rgba(0,0,0,0.8)',
            }}
          >
            Passive Monitoring.
          </h2>
        </div>
        <div
          className="absolute z-10 flex items-center justify-center"
          style={{ top: '50%', left: '50%', transform: 'translateX(-50%)' }}
        >
          <h2
            className="font-display text-center font-medium"
            style={{
              fontSize: '40px',
              lineHeight: 1.1,
              color: '#ff442e',
              textShadow: '0px 0px 4px rgba(0,0,0,0.8)',
            }}
          >
            Active Intrusion Detected.
          </h2>
        </div>
        <div
          className="absolute z-10 flex items-center justify-center"
          style={{ top: '80%', left: '50%', transform: 'translateX(-50%)' }}
        >
          <h2
            className="font-display text-center font-medium"
            style={{
              fontSize: '40px',
              lineHeight: 1.1,
              color: '#f1f1ef',
              textShadow: '0px 0px 4px rgba(0,0,0,0.8)',
            }}
          >
            Threat Neutralized.
          </h2>
        </div>
      </div>
    </section>
  );
}
