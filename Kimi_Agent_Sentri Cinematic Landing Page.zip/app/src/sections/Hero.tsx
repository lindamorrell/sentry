import { useRef, useEffect } from 'react';
import HeroFluid from './HeroFluid';
import gsap from 'gsap';

export default function Hero() {
  const textRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (textRef.current) {
      gsap.fromTo(
        textRef.current,
        { opacity: 0, y: 30 },
        { opacity: 1, y: 0, duration: 1.2, ease: 'power2.out', delay: 0.3 }
      );
    }
  }, []);

  return (
    <section
      id="response"
      className="relative overflow-hidden"
      style={{ height: '100vh', width: '100vw' }}
    >
      <HeroFluid />
      <div
        className="absolute inset-0 flex items-center justify-center"
        style={{ zIndex: 10, pointerEvents: 'none' }}
      >
        <div
          ref={textRef}
          className="text-center"
          style={{ maxWidth: '900px', padding: '0 24px' }}
        >
          <span
            className="font-mono"
            style={{
              fontSize: '14px',
              fontWeight: 400,
              letterSpacing: '0.5px',
              textTransform: 'uppercase',
              color: '#26ff6a',
              display: 'block',
              marginBottom: '24px',
            }}
          >
            Independent Cybersecurity — Sydney
          </span>
          <h1
            className="font-display font-medium"
            style={{
              fontSize: 'clamp(36px, 5vw, 64px)',
              lineHeight: 1.0,
              color: '#c4cec5',
              textShadow: '0px 0px 4px rgba(0,0,0,0.8)',
              letterSpacing: '-0.01em',
            }}
          >
            Autonomous digital threat neutralization
          </h1>
          <div
            style={{
              marginTop: '32px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '32px',
            }}
          >
            <a
              href="#contact"
              className="font-display font-medium"
              style={{
                fontSize: '16px',
                padding: '16px 32px',
                backgroundColor: '#26ff6a',
                color: '#000000',
                textDecoration: 'none',
                pointerEvents: 'auto',
              }}
              onClick={(e) => {
                e.preventDefault();
                document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              Initiate Protocol
            </a>
            <a
              href="#methodology"
              className="font-body"
              style={{
                fontSize: '16px',
                color: '#c4cec5',
                textDecoration: 'none',
                pointerEvents: 'auto',
                opacity: 0.7,
              }}
              onClick={(e) => {
                e.preventDefault();
                document.querySelector('#methodology')?.scrollIntoView({ behavior: 'smooth' });
              }}
              onMouseEnter={(e) => { (e.target as HTMLElement).style.opacity = '1'; }}
              onMouseLeave={(e) => { (e.target as HTMLElement).style.opacity = '0.7'; }}
            >
              Explore Methodology
            </a>
          </div>
        </div>
      </div>
      {/* Scroll indicator */}
      <div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        style={{ zIndex: 10 }}
      >
        <div
          className="font-mono"
          style={{
            fontSize: '12px',
            color: '#c4cec5',
            opacity: 0.4,
            letterSpacing: '0.5px',
            textTransform: 'uppercase',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: '8px',
          }}
        >
          <span>Scroll</span>
          <div
            style={{
              width: '1px',
              height: '32px',
              backgroundColor: '#c4cec5',
              opacity: 0.3,
            }}
          />
        </div>
      </div>
    </section>
  );
}
