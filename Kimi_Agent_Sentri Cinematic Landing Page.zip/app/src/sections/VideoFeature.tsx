import { useRef, useEffect } from 'react';

interface VideoFeatureProps {
  videoSrc: string;
  overlayTitle: string;
}

export default function VideoFeature({ videoSrc, overlayTitle }: VideoFeatureProps) {
  const videoSectionRef = useRef<HTMLDivElement>(null);
  const videoContainerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const glitchBarRef = useRef<HTMLDivElement>(null);
  const mouseXRef = useRef(0);
  const mouseYRef = useRef(0);
  const sectionMouseXRef = useRef(0);
  const sectionMouseYRef = useRef(0);
  const cardRotXRef = useRef(0);
  const cardRotYRef = useRef(0);
  const rafRef = useRef(0);

  useEffect(() => {
    const videoSection = videoSectionRef.current;
    const videoContainer = videoContainerRef.current;
    const videoElement = videoRef.current;
    const glitchBar = glitchBarRef.current;
    if (!videoSection || !videoContainer || !videoElement || !glitchBar) return;

    const config = {
      maxRotation: 20,
      damping: 0.1,
      wobbleSpeed: 0.002,
      wobbleAmp: 1,
      breathAmp: 0.5,
    };

    let targetRotX = 0;
    let targetRotY = 0;

    const handleDocumentMouseMove = (e: MouseEvent) => {
      mouseXRef.current = e.clientX;
      mouseYRef.current = e.clientY;
    };

    const handleSectionMouseMove = (e: MouseEvent) => {
      const sectionRect = videoSection.getBoundingClientRect();
      sectionMouseXRef.current = ((e.clientX - sectionRect.left) / sectionRect.width) - 0.5;
      sectionMouseYRef.current = ((e.clientY - sectionRect.top) / sectionRect.height) - 0.5;
    };

    document.addEventListener('mousemove', handleDocumentMouseMove);
    videoSection.addEventListener('mousemove', handleSectionMouseMove);

    const update = (time: number) => {
      targetRotY = sectionMouseXRef.current * config.maxRotation;
      targetRotX = -sectionMouseYRef.current * config.maxRotation;

      cardRotXRef.current += (targetRotX - cardRotXRef.current) * config.damping;
      cardRotYRef.current += (targetRotY - cardRotYRef.current) * config.damping;

      const wobble = Math.sin(time * config.wobbleSpeed) * config.wobbleAmp;
      const breath = 1 + Math.sin(time * 0.001) * config.breathAmp * 0.01;

      const parallaxX = (mouseXRef.current / window.innerWidth - 0.5) * -20;
      const parallaxY = (mouseYRef.current / window.innerHeight - 0.5) * -20;

      videoContainer.style.transform = `scale(${breath}) rotateX(${cardRotXRef.current + wobble}deg) rotateY(${cardRotYRef.current + wobble}deg)`;
      videoElement.style.transform = `translate(${parallaxX}px, ${parallaxY}px) scale(1.1)`;
      glitchBar.style.transform = `translateX(${( (time * 0.2) % 140 ) - 10}%)`;

      rafRef.current = requestAnimationFrame(update);
    };

    rafRef.current = requestAnimationFrame(update);

    return () => {
      cancelAnimationFrame(rafRef.current);
      document.removeEventListener('mousemove', handleDocumentMouseMove);
      videoSection.removeEventListener('mousemove', handleSectionMouseMove);
    };
  }, []);

  return (
    <section
      ref={videoSectionRef}
      className="relative flex items-center justify-center overflow-hidden"
      style={{ perspective: '2000px', height: '100vh', backgroundColor: '#151515' }}
    >
      <div
        ref={videoContainerRef}
        className="relative overflow-hidden"
        style={{
          width: '80vw',
          height: '45vw',
          transformStyle: 'preserve-3d',
          willChange: 'transform',
          borderRadius: '0px',
        }}
      >
        <video
          ref={videoRef}
          src={videoSrc}
          autoPlay
          muted
          loop
          playsInline
          className="block"
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            willChange: 'transform',
          }}
        />
        <div
          ref={glitchBarRef}
          className="pointer-events-none absolute top-0 left-0 h-full"
          style={{
            width: '10px',
            background: 'rgba(38, 255, 106, 0.1)',
            mixBlendMode: 'overlay',
            zIndex: 10,
          }}
        />
        {/* Overlay card */}
        <div
          className="absolute bottom-6 left-6 z-20 p-6"
          style={{
            border: '1px solid #26ff6a',
            backgroundColor: 'rgba(0, 0, 0, 0.6)',
            backdropFilter: 'blur(4px)',
          }}
        >
          <h3
            className="font-display text-2xl font-medium"
            style={{ color: '#f1f1ef', lineHeight: 1.2 }}
          >
            {overlayTitle}
          </h3>
        </div>
      </div>
    </section>
  );
}
