import { useRef, useEffect, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Send, CheckCircle } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function RetainerForm() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    size: '',
    message: '',
  });

  useEffect(() => {
    if (titleRef.current) {
      gsap.fromTo(
        titleRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: titleRef.current,
            start: 'top 80%',
          },
        }
      );
    }
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <section
      ref={sectionRef}
      id="contact"
      style={{
        backgroundColor: '#000000',
        padding: '160px 24px',
      }}
    >
      <div style={{ maxWidth: '800px', margin: '0 auto' }}>
        <div className="flex items-center gap-4" style={{ marginBottom: '16px' }}>
          <span
            className="font-mono"
            style={{
              fontSize: '14px',
              fontWeight: 400,
              letterSpacing: '0.5px',
              textTransform: 'uppercase',
              color: '#26ff6a',
            }}
          >
            Retainer Inquiry
          </span>
          <div style={{ flex: 1, height: '1px', backgroundColor: '#c4cec5', opacity: 0.15 }} />
        </div>
        <h2
          ref={titleRef}
          className="font-display font-medium"
          style={{
            fontSize: '40px',
            lineHeight: 1.1,
            color: '#f1f1ef',
            marginBottom: '24px',
          }}
        >
          Engage Sentri
        </h2>
        <p
          className="font-body"
          style={{
            fontSize: '18px',
            lineHeight: 1.4,
            color: '#c4cec5',
            opacity: 0.6,
            marginBottom: '64px',
          }}
        >
          Ready to move beyond checkbox compliance and reactive security? Tell us about your environment and we will respond within 24 hours.
        </p>

        {submitted ? (
          <div
            className="flex flex-col items-center justify-center"
            style={{ padding: '80px 0', textAlign: 'center' }}
          >
            <CheckCircle size={48} style={{ color: '#26ff6a', marginBottom: '24px' }} />
            <h3
              className="font-display font-medium"
              style={{
                fontSize: '28px',
                lineHeight: 1.2,
                color: '#f1f1ef',
                marginBottom: '12px',
              }}
            >
              Inquiry received
            </h3>
            <p
              className="font-body"
              style={{
                fontSize: '16px',
                lineHeight: 1.5,
                color: '#c4cec5',
                opacity: 0.6,
              }}
            >
              Our team will review your requirements and respond within 24 hours. For urgent matters, call our operations centre directly.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            <div className="grid grid-cols-1 md:grid-cols-2" style={{ gap: '24px' }}>
              <FormField
                label="Full Name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                required
              />
              <FormField
                label="Business Email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2" style={{ gap: '24px' }}>
              <FormField
                label="Company Name"
                name="company"
                type="text"
                value={formData.company}
                onChange={handleChange}
                required
              />
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <label
                  className="font-mono"
                  style={{
                    fontSize: '12px',
                    fontWeight: 400,
                    letterSpacing: '0.5px',
                    textTransform: 'uppercase',
                    color: '#c4cec5',
                    opacity: 0.5,
                  }}
                >
                  Organisation Size
                </label>
                <select
                  name="size"
                  value={formData.size}
                  onChange={handleChange}
                  required
                  className="font-body"
                  style={{
                    padding: '16px',
                    backgroundColor: 'transparent',
                    border: '1px solid rgba(196, 206, 197, 0.2)',
                    color: '#f1f1ef',
                    fontSize: '16px',
                    outline: 'none',
                    appearance: 'none',
                    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23c4cec5' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E")`,
                    backgroundRepeat: 'no-repeat',
                    backgroundPosition: 'right 16px center',
                  }}
                >
                  <option value="" disabled style={{ backgroundColor: '#151515' }}>Select size</option>
                  <option value="1-10" style={{ backgroundColor: '#151515' }}>1–10 employees</option>
                  <option value="11-50" style={{ backgroundColor: '#151515' }}>11–50 employees</option>
                  <option value="51-200" style={{ backgroundColor: '#151515' }}>51–200 employees</option>
                  <option value="200+" style={{ backgroundColor: '#151515' }}>200+ employees</option>
                </select>
              </div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <label
                className="font-mono"
                style={{
                  fontSize: '12px',
                  fontWeight: 400,
                  letterSpacing: '0.5px',
                  textTransform: 'uppercase',
                  color: '#c4cec5',
                  opacity: 0.5,
                }}
              >
                Tell us about your security needs
              </label>
              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                rows={5}
                className="font-body"
                style={{
                  padding: '16px',
                  backgroundColor: 'transparent',
                  border: '1px solid rgba(196, 206, 197, 0.2)',
                  color: '#f1f1ef',
                  fontSize: '16px',
                  outline: 'none',
                  resize: 'vertical',
                  lineHeight: 1.5,
                }}
                placeholder="Current infrastructure, compliance requirements, known concerns..."
              />
            </div>
            <button
              type="submit"
              className="font-display font-medium flex items-center justify-center gap-3 group"
              style={{
                padding: '20px 48px',
                backgroundColor: '#26ff6a',
                color: '#000000',
                fontSize: '16px',
                border: 'none',
                cursor: 'pointer',
                alignSelf: 'flex-start',
                transition: 'none',
              }}
            >
              <span>Submit inquiry</span>
              <Send size={18} />
            </button>
          </form>
        )}
      </div>
    </section>
  );
}

function FormField({
  label,
  name,
  type,
  value,
  onChange,
  required,
}: {
  label: string;
  name: string;
  type: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  required?: boolean;
}) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <label
        className="font-mono"
        style={{
          fontSize: '12px',
          fontWeight: 400,
          letterSpacing: '0.5px',
          textTransform: 'uppercase',
          color: '#c4cec5',
          opacity: 0.5,
        }}
      >
        {label}
      </label>
      <input
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        required={required}
        className="font-body"
        style={{
          padding: '16px',
          backgroundColor: 'transparent',
          border: '1px solid rgba(196, 206, 197, 0.2)',
          color: '#f1f1ef',
          fontSize: '16px',
          outline: 'none',
        }}
      />
    </div>
  );
}
