import { useEffect, useRef } from 'react';
import Lenis from '@studio-freight/lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

import Navigation from './sections/Navigation';
import Hero from './sections/Hero';
import VideoFeature from './sections/VideoFeature';
import ThreatAnalysis from './sections/ThreatAnalysis';
import StateShiftingFluid from './sections/StateShiftingFluid';
import OperationalSectors from './sections/OperationalSectors';
import Methodology from './sections/Methodology';
import CaseStudies from './sections/CaseStudies';
import Compliance from './sections/Compliance';
import Onboarding from './sections/Onboarding';
import RetainerForm from './sections/RetainerForm';
import Footer from './sections/Footer';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const lenisRef = useRef<Lenis | null>(null);

  useEffect(() => {
    const lenis = new Lenis({
      lerp: 0.15,
      smoothWheel: true,
    });
    lenisRef.current = lenis;

    // Sync Lenis with GSAP ScrollTrigger
    lenis.on('scroll', ScrollTrigger.update);

    gsap.ticker.add((time) => {
      lenis.raf(time * 1000);
    });

    gsap.ticker.lagSmoothing(0);

    return () => {
      lenis.destroy();
      gsap.ticker.remove(lenis.raf as unknown as gsap.TickerCallback);
    };
  }, []);

  return (
    <div className="relative">
      <Navigation />
      <Hero />
      <VideoFeature
        videoSrc="/videos/server-rack.mp4"
        overlayTitle="Real-time anomaly detection"
      />
      <ThreatAnalysis />
      <StateShiftingFluid />
      <OperationalSectors />
      <Methodology />
      <VideoFeature
        videoSrc="/videos/circuit-board.mp4"
        overlayTitle="Behavioral topology mapping"
      />
      <CaseStudies />
      <Compliance />
      <Onboarding />
      <RetainerForm />
      <Footer />
    </div>
  );
}

export default App;
